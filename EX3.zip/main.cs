using System;

class Program
{
    static void Main(string[] args)
    {
        int divisivelPor3e9 = 0;
        int divisivelPor2e5 = 0;

        for (int i = 1; i <= 10; i++)
        {
            Console.Write($"Digite o {i}º número: ");
            int numero = int.Parse(Console.ReadLine());

            // Verifica divisibilidade por 3 e 9
            int somaDigitos = 0;
            int temp = numero;
            while (temp > 0)
            {
                somaDigitos += temp % 10;
                temp /= 10;
            }
            if (somaDigitos % 3 == 0 && somaDigitos % 9 == 0)
                divisivelPor3e9++;

            // Verifica divisibilidade por 2 e 5
            if (numero % 2 == 0 && numero % 5 == 0)
                divisivelPor2e5++;
        }

        Console.WriteLine($"Quantidade de números divisíveis por 3 e 9: {divisivelPor3e9}");
        Console.WriteLine($"Quantidade de números divisíveis por 2 e 5: {divisivelPor2e5}");
    }
}
