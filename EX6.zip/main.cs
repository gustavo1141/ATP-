using System;

class Program
{
    static void Main(string[] args)
    {

        double[] salarios = { 2500.50, 3200.75, 1800.90, 4000.60, 2900.45 };

        double mediaSalarios = CalcularMediaSalarios(salarios);

        Console.WriteLine($"A média do salário da população é: {mediaSalarios:C}");
    }

    static double CalcularMediaSalarios(double[] salarios)
    {
        double soma = 0;

        foreach (double salario in salarios)
        {
            soma += salario;
        }

        return soma / salarios.Length;
    }
}
