using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite um número inteiro e positivo para calcular a soma:");
        int n = int.Parse(Console.ReadLine());

        if (n <= 0)
        {
            Console.WriteLine("Número inválido. O número deve ser positivo.");
            return;
        }

        double soma = 0.0;

        for (int i = 1; i <= n; i++)
        {
            double termo = 1.0 / i;
            soma += termo;
            Console.WriteLine($"Termo {i}: {termo:F4}");
        }

        Console.WriteLine($"Valor final de S: {soma:F4}");
    }
}
