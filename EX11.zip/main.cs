using System;

class MainClass {
    public static void Main (string[] args) {
        
        int[] votosCandidatos = new int[4];
        int votosNulos = 0;
        int votosBrancos = 0;

        
        while (true) {
            Console.WriteLine("Digite o código do voto (1 a 6, 0 para encerrar):");
            int codigo = Convert.ToInt32(Console.ReadLine());

            
            if (codigo == 0) {
                break;
            }

            
            switch (codigo) {
                case 1:
                case 2:
                case 3:
                case 4:
                    votosCandidatos[codigo - 1]++;
                    break;
                case 5:
                    votosNulos++;
                    break;
                case 6:
                    votosBrancos++;
                    break;
                default:
                    Console.WriteLine("Código de voto inválido.");
                    break;
            }
        }

       
        Console.WriteLine("Total de votos para cada candidato:");
        for (int i = 0; i < votosCandidatos.Length; i++) {
            Console.WriteLine($"Candidato {i+1}: {votosCandidatos[i]} votos");
        }
        Console.WriteLine($"Total de votos nulos: {votosNulos}");
        Console.WriteLine($"Total de votos em branco: {votosBrancos}");
    }
}
