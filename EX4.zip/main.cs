using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite um número natural para calcular o fatorial:");
        int numero = Convert.ToInt32(Console.ReadLine());

        if (numero < 0)
        {
            Console.WriteLine("Número inválido. O número deve ser maior ou igual a zero.");
        }
        else
        {
            long fatorial = CalcularFatorial(numero);
            Console.WriteLine($"O fatorial de {numero} é {fatorial}.");
        }
    }

    static long CalcularFatorial(int n)
    {
        if (n == 0)
        {
            return 1;
        }
        else
        {
            long resultado = 1;
            for (int i = 1; i <= n; i++)
            {
                resultado *= i;
            }
            return resultado;
        }
    }
}
