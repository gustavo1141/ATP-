using System;

class Program
{
    static void Main(string[] args)
    {
        double totalCompra = 0.0;
        double totalVenda = 0.0;

        Console.WriteLine("Informe o preço de compra da mercadoria (ou digite 0 para encerrar):");

        while (true)
        {
            double precoCompra = double.Parse(Console.ReadLine());

            if (precoCompra == 0)
            {
                break;
            }

            Console.WriteLine("Informe o preço de venda da mercadoria:");
            double precoVenda = double.Parse(Console.ReadLine());

            totalCompra += precoCompra;
            totalVenda += precoVenda;
        }

        Console.WriteLine($"Valor total de compra de todas as mercadorias: {totalCompra:C}");
        Console.WriteLine($"Valor total de venda de todas as mercadorias: {totalVenda:C}");
    }
}
