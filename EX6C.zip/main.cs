using System;

class Program
{
    static void Main(string[] args)
    {

        double[] salarios = { 2500.50, 3200.75, 1800.90, 4000.60, 2900.45 };

        double maiorSalario = EncontrarMaiorSalario(salarios);

        Console.WriteLine($"O maior salário entre os habitantes é: {maiorSalario:C}");
    }

    static double EncontrarMaiorSalario(double[] salarios)
    {
        double maiorSalario = salarios[0];

        foreach (double salario in salarios)
        {
            if (salario > maiorSalario)
            {
                maiorSalario = salario;
            }
        }

        return maiorSalario;
    }
}
