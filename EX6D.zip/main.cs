using System;

class Program
{
    static void Main(string[] args)
    {

        double[] salarios = { 2500.50, 3200.75, 1800.90, 4000.60, 2900.45, 50.0, 80.0, 120.0 };

        double percentualSalarioAte100 = CalcularPercentualSalarioAte100(salarios);

        Console.WriteLine($"O percentual de pessoas com salário até R$100,00 é: {percentualSalarioAte100:F}%");
    }

    static double CalcularPercentualSalarioAte100(double[] salarios)
    {
        int contadorSalarioAte100 = 0;

        foreach (double salario in salarios)
        {
            if (salario <= 100.0)
            {
                contadorSalarioAte100++;
            }
        }

        return (contadorSalarioAte100 / (double)salarios.Length) * 100.0;
    }
}
