using System;

class Program
{
    static void Main(string[] args)
    {

        int[] numFilhos = { 2, 3, 1, 4, 2 };

        double mediaNumFilhos = CalcularMediaNumFilhos(numFilhos);

        Console.WriteLine($"A média do número de filhos da população é: {mediaNumFilhos:F}");
    }

    static double CalcularMediaNumFilhos(int[] numFilhos)
    {
        double soma = 0;

        foreach (int numFilho in numFilhos)
        {
            soma += numFilho;
        }

        return soma / numFilhos.Length;
    }
}
