using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite o valor limite (L) para a soma dos elementos da série de Fibonacci:");
        int L = int.Parse(Console.ReadLine());

        if (L <= 0)
        {
            Console.WriteLine("Número inválido. Por favor, digite um número maior que zero.");
            return;
        }

        int primeiroTermo = 0;
        int segundoTermo = 1;
        int proximoTermo = 0;
        int soma = 0;

        while (proximoTermo < L)
        {
            proximoTermo = primeiroTermo + segundoTermo;
            if (proximoTermo < L)
            {
                soma += proximoTermo;
            }
            primeiroTermo = segundoTermo;
            segundoTermo = proximoTermo;
        }

        Console.WriteLine($"A soma de todos os elementos da série de Fibonacci menores que {L} é: {soma}");
    }
}
