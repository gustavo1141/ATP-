using System;

class Program
{
    static void Main(string[] args)
    {
        int lucroMenor10 = 0;
        int lucroEntre10e20 = 0;
        int lucroMaior20 = 0;

        Console.WriteLine("Informe o preço de compra da mercadoria (ou digite 0 para encerrar):");

        while (true)
        {
            double precoCompra = double.Parse(Console.ReadLine());

            if (precoCompra == 0)
            {
                break;
            }

            Console.WriteLine("Informe o preço de venda da mercadoria:");
            double precoVenda = double.Parse(Console.ReadLine());

            double lucroPercentual = ((precoVenda - precoCompra) / precoCompra) * 100;

            if (lucroPercentual < 10)
            {
                lucroMenor10++;
            }
            else if (lucroPercentual >= 10 && lucroPercentual <= 20)
            {
                lucroEntre10e20++;
            }
            else
            {
                lucroMaior20++;
            }
        }

        Console.WriteLine($"Quantidade de mercadorias com lucro < 10%: {lucroMenor10}");
        Console.WriteLine($"Quantidade de mercadorias com lucro entre 10% e 20%: {lucroEntre10e20}");
        Console.WriteLine($"Quantidade de mercadorias com lucro > 20%: {lucroMaior20}");
    }
}
