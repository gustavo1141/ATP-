using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite uma sequência de valores inteiros separados por espaço:");
        string input = Console.ReadLine();

        string[] valores = input.Split(' ');

        int positivos = 0;
        int negativos = 0;
        int zeros = 0;

        foreach (string valor in valores)
        {
            int numero = int.Parse(valor);
            if (numero > 0)
            {
                positivos++;
            }
            else if (numero < 0)
            {
                negativos++;
            }
            else
            {
                zeros++;
            }
        }

        Console.WriteLine("Quantidade de valores positivos: " + positivos);
        Console.WriteLine("Quantidade de valores negativos: " + negativos);
        Console.WriteLine("Quantidade de zeros: " + zeros);
    }
}
