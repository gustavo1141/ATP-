using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite o número de elementos da sequência de Fibonacci a serem mostrados:");
        int L = int.Parse(Console.ReadLine());

        if (L <= 0)
        {
            Console.WriteLine("Número inválido. Por favor, digite um número maior que zero.");
            return;
        }

        int primeiroTermo = 0;
        int segundoTermo = 1;

        Console.WriteLine($"Os {L} primeiros elementos da sequência de Fibonacci:");

        if (L >= 1)
        {
            Console.WriteLine(primeiroTermo);
        }
        if (L >= 2)
        {
            Console.WriteLine(segundoTermo);
        }

        for (int i = 3; i <= L; i++)
        {
            int proximoTermo = primeiroTermo + segundoTermo;
            Console.WriteLine(proximoTermo);
            primeiroTermo = segundoTermo;
            segundoTermo = proximoTermo;
        }
    }
}
